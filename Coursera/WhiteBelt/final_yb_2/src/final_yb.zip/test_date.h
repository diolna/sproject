#pragma once

#include "date.h"
#include "test_runner.h"

using namespace std;

void TestParseDate();
void TestDateComparison();
void TestDate();
